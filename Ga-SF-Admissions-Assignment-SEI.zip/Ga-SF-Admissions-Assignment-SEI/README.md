#GA SF Admissions Assignment

This is the admission assignment for General Assembly in San Francisco. Open the `index.html` file to get started.

For issues or feedback contact [one of the creators](mailto: ilias@ga.co).
